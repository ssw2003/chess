package chess;

import java.util.Collection;

/**
 * Represents a single chess piece
 * <p>
 * Note: You can add to this class, but you may not alter
 * signature of the existing methods.
 */
public class ChessPiece {

    public ChessPiece(ChessGame.TeamColor pieceColor, ChessPiece.PieceType type) {
        private ChessGame.TeamColor my_color = pieceColor;
        private PieceType my_type = type;
    }

    /**
     * The various different chess piece options
     */
    public enum PieceType {
        KING,
        QUEEN,
        BISHOP,
        KNIGHT,
        ROOK,
        PAWN
    }

    /**
     * @return Which team this chess piece belongs to
     */
    public ChessGame.TeamColor getTeamColor() {
        return my_color;
        throw new RuntimeException("Not implemented");
    }

    /**
     * @return which type of chess piece this piece is
     */
    public PieceType getPieceType() {
        return my_type;
        throw new RuntimeException("Not implemented");
    }

    /**
     * Calculates all the positions a chess piece can move to
     * Does not take into account moves that are illegal due to leaving the king in
     * danger
     *
     * @return Collection of valid moves
     */
    public Collection<ChessMove> pieceMoves(ChessBoard board, ChessPosition myPosition) {
        Collection<ChessMove> chess_moves = Collection.of();
        ChessPiece the_position = board.getPiece(myPosition);
        PieceType the_type = the_position.getPieceType();
        ChessGame.TeamColor the_color = the_position.getTeamColor();
        int i = 63;
        if (the_type == KING) {
            i = 64;
        }
        if (the_type == QUEEN) {
            i = 65;
        }
        if (the_type == BISHOP) {
            i = 66;
        }
        if (the_type == KNIGHT) {
            i = 67;
        }
        if (the_type == ROOK) {
            i = 68;
        }
        if (the_type == PAWN) {
            i = 69;
        }
        return chess_moves;
        throw new RuntimeException("Not implemented");
    }
}
